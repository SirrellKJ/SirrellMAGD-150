let gui;
let b;
let bank = 0;
let t;
let b2
let mill = 0
let j;
let x, y, velX, velY;

function setup() {
  createCanvas(400, 400);
  
  gui = createGui();
  b = createButton("Button", 50, 270,60,40);
  t = createToggle("Tool Select", 290, 5, 108, 30);
  b2 = createButton(".",320,230,30,70)

  j = createJoystick("Joystick", 10, 10, 75, 75, -1, 1, 1, -1);
  x     = 200;
  y     = 350;
  velX  = 0;
  velY  = 0;
}

function draw() {
  background(220);
  fill(40,50,200)
  rect(0,0,400,300)
  fill(70,200,50)
  rect(0,250,400,150)
  text("Bank: "+Math.floor(bank)+"gp",300,50)
  text("Mill: "+Math.floor(mill)+" Logs",300,63)
  drawGui();
  fill(190)
  rect(50,270,60,40)
  fill(0)
  text("Gold Mine",53,290)
  fill(150,75,0)
  rect(320,230,30,70)
  fill(50,150,20)
  circle(335,210,50)

  if(t.val == false){
    text("Tool: Pickaxe",300,74)
  } else {
    text("Tool: Woodaxe",300,74)
  }

  if(b.isPressed) {
    if (t.val == false){
      bank += 5;
    }
  }

  if(b2.isPressed) {
    if (t.val == true){
      mill += 1;
    }
  }

  velX += j.valX;
  velY += j.valY;

  let ellipseX = x + velX
  let ellipseY = y + velY
  fill(0);
  ellipse(ellipseX,ellipseY, 23);

  if (ellipseX > 50 && ellipseX < 110){
    if((ellipseY > 270 && ellipseY < 310)){
      bank += 0.012
    }
  }

  if (ellipseX > 320 && ellipseX < 350){
    if((ellipseY > 230 && ellipseY < 300)){
      mill += 0.005
    }
  }

  
}