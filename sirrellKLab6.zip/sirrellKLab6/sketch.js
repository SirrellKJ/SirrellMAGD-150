let snowflakeY = []; 

function setup() {
  createCanvas(400, 400);
  noStroke();
  fill(255, 200);
  for (let i = 0; i < 10000; i++) {
    snowflakeY[i] = random(-600, 400);
  }
  console.log("snowflakeY Array Length: "+snowflakeY.length)
}

function draw() {
  background(0);
  fill(255)
  rect(0,400,400,-50)
  fill(150,75,30)
  rect(40,375,10,-20)
  fill(50,200,12)
  triangle(35,365,55,365,45,345)
  triangle(35,355,55,355,45,335)
  
  fill(255, 200)
  for (let i = 0; i < snowflakeY.length; i++) {
    snowflakeY[i] += 0.7;
    let x = i * 0.4;
    circle(x, snowflakeY[i], 5);
  }
}