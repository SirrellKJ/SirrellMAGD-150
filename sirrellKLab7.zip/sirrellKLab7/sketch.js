let dockedShips = ["USS Constitution", "USS Connecticut", "USS Obama", "HMS Queen Elizabeth", "HMS Dragon", "HMS Bangor","ROKS Wang Geon", "ROKS Gang Gam-chan", "ROKS Munmu"];
let deployedShips = [];
let deployedShipsX = [];
let deployedShipsY = [];

function setup() {
  createCanvas(800, 800);
  background(60,60,200);
  for (let p = 0; p<5; p++){
    let num = Math.floor(random(0,dockedShips.length));
    console.log(num);
    deployedShips.push(dockedShips[num]);
    dockedShips.splice(num,1);
    deployedShipsX.push(random(10,width-100));
    deployedShipsY.push(random(10,height-100));
  }
  console.log(deployedShips);
  for (let n = 0; n<deployedShips.length; n++){
    text(deployedShips[n],deployedShipsX[n],deployedShipsY[n]);    
  }
  text("The ships we have docked are: "+dockedShips,50,760);
  text("The number of docked ships: "+dockedShips.length,50,780);
}